<?php
$config['wblist_limit'] = 15;
$config['wblist_default_policy'] = 5;