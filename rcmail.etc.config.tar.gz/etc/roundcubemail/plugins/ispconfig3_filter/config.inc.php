<?php
$config['filter_limit'] = 15;