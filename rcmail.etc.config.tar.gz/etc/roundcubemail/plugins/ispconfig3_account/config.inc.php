<?php
$config['identity_limit'] = false;
$config['remote_soap_user'] = 'roundcubemail_plugin';
$config['remote_soap_pass'] = 'ffC#r9HXHi';
$config['soap_url'] = 'https://nexttime.fixvps.hu:8888/remote/';
$config['soap_validate_cert'] = true;
