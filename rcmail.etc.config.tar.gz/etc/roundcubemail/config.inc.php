<?php

/*
 +-----------------------------------------------------------------------+
 | Local configuration for the Roundcube Webmail installation.           |
 |                                                                       |
 | This is a sample configuration file only containing the minimum       |
 | setup required for a functional installation. Copy more options       |
 | from defaults.inc.php to this file to override the defaults.          |
 |                                                                       |
 | This file is part of the Roundcube Webmail client                     |
 | Copyright (C) The Roundcube Dev Team                                  |
 |                                                                       |
 | Licensed under the GNU General Public License version 3 or            |
 | any later version with exceptions for skins & plugins.                |
 | See the README file for a full license statement.                     |
 +-----------------------------------------------------------------------+
*/

$config = [];

// Database connection string (DSN) for read+write operations
// Format (compatible with PEAR MDB2): db_provider://user:password@host/database
// Currently supported db_providers: mysql, pgsql, sqlite, mssql, sqlsrv, oracle
// For examples see http://pear.php.net/manual/en/package.database.mdb2.intro-dsn.php
// NOTE: for SQLite use absolute path (Linux): 'sqlite:////full/path/to/sqlite.db?mode=0646'
//       or (Windows): 'sqlite:///C:/full/path/to/sqlite.db'
#$config['db_dsnw'] = 'mysql://roundcube:pass@localhost/roundcubemail';
$config['db_dsnw'] = 'mysql://roundcubemail:v6wHtwAd#u@)HMJs@localhost/roundcubemail';


$config['debug_level'] = 4;

$config['log_logins'] = true;
$config['log_session'] = true;
$config['sql_debug'] = false;
$config['imap_debug'] = true;
$config['smtp_debug'] = true;

$config['language'] = 'hu_HU';

$config['imap_vendor'] = 'dovecot';


// The IMAP host chosen to perform the log-in.
// Leave blank to show a textbox at login, give a list of hosts
// to display a pulldown menu or set one host as string.
// Enter hostname with prefix ssl:// to use Implicit TLS, or use
// prefix tls:// to use STARTTLS.
// Supported replacement variables:
// %n - hostname ($_SERVER['SERVER_NAME'])
// %t - hostname without the first part
// %d - domain (http hostname $_SERVER['HTTP_HOST'] without the first part)
// %s - domain name after the '@' from e-mail address provided at login screen
// For example %n = mail.domain.tld, %t = domain.tld
//$config['default_host'] = 'localhost';

#$config['default_host'] = 'ssl://nexttime.fixvps.hu';
#$config['default_port'] = '993';
#$config['default_host'] = 'tls://nexttime.fixvps.hu';
#$config['default_port'] = '143';
$config['default_host'] = 'ssl://localhost';
$config['default_port'] = '993';

$config['imap_auth_type'] = 'LOGIN';
$config['imap_delimiter'] = '/';

$config['imap_conn_options'] = [
    'ssl' => [
	'verify_peer'  => false,
	'verify_peer_name' => false,
    ],
];

// SMTP server host (for sending mails).
// Enter hostname with prefix ssl:// to use Implicit TLS, or use
// prefix tls:// to use STARTTLS.
// Supported replacement variables:
// %h - user's IMAP hostname
// %n - hostname ($_SERVER['SERVER_NAME'])
// %t - hostname without the first part
// %d - domain (http hostname $_SERVER['HTTP_HOST'] without the first part)
// %z - IMAP domain (IMAP hostname without the first part)
// For example %n = mail.domain.tld, %t = domain.tld
// To specify different SMTP servers for different IMAP hosts provide an array
// of IMAP host (no prefix or port) and SMTP server e.g. ['imap.example.com' => 'smtp.example.net']
#$config['smtp_server'] = 'localhost';

#$config['smtp_server'] = 'tls://nexttime.fixvps.hu';
$config['smtp_server'] = 'tls://localhost';

// SMTP port. Use 25 for cleartext, 465 for Implicit TLS, or 587 for STARTTLS (default)
$config['smtp_port'] = 587;

$config['smtp_conn_options'] = [
    'ssl' => [
	'verify_peer'  => false,
	'verify_peer_name' => false,
	//'peer_name' => 'nexttime.fixvps.hu',
	//'cafile' => '/etc/letsencrypt/live/nexttime.fixvps.hu/fullchain.pem',
    ],
];

// SMTP username (if required) if you use %u as the username Roundcube
// will use the current username for login
$config['smtp_user'] = '%u';

// SMTP password (if required) if you use %p as the password Roundcube
// will use the current user's password for login
$config['smtp_pass'] = '%p';

// provide an URL where a user can get support for this Roundcube installation
// PLEASE DO NOT LINK TO THE ROUNDCUBE.NET WEBSITE HERE!
#$config['support_url'] = '';
$config['support_url'] = 'mailto:support@fixvps.hu';

// Name your service. This is displayed on the login screen and in the window title
$config['product_name'] = 'Roundcube Webmail';

// This key is used to encrypt the users imap password which is stored
// in the session record. For the default cipher method it must be
// exactly 24 characters long.
// YOUR KEY MUST BE DIFFERENT THAN THE SAMPLE VALUE FOR SECURITY REASONS
$config['des_key'] = 'rcmail-!24ByteDESkey*Str';

// List of active plugins (in plugins/ directory)
$config['plugins'] = [
	'jqueryui',
	'archive',
	'filesystem_attachments',
	'help',
	'ispconfig3_account',
	'ispconfig3_autoreply',
	'ispconfig3_fetchmail',
	'ispconfig3_filter',
	'ispconfig3_forward',
	'ispconfig3_pass',
	'ispconfig3_spam',
	'ispconfig3_wblist',
	'libcalendaring',
	'libkolab',
	'newmail_notifier',
	'show_additional_headers',
	'tasklist',
	'userinfo',
	'vcard_attachments',
	'zipdownload',
	'calendar',
];

// skin name: folder from skins/
$config['skin'] = 'elastic';

// Disable spellchecking
// Debian: spellshecking needs additional packages to be installed, or calling external APIs
//         see defaults.inc.php for additional informations
$config['enable_spellcheck'] = false;
