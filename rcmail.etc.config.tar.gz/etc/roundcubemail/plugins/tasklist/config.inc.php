<?php

// backend type (database, kolab)
$config['tasklist_driver'] = 'database';

// default sorting order of tasks listing (auto, datetime, startdatetime, flagged, complete, changed)
$config['tasklist_sort_col'] = '';

// default sorting order for tasks listing (asc or desc)
$config['tasklist_sort_order'] = 'asc';

