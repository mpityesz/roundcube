<?php
$config['password_confirm_current'] = true;
#$config['password_min_length'] = 6;
$config['password_check_symbol'] = true;
$config['password_check_lower'] = true;
$config['password_check_upper'] = true;
$config['password_check_number'] = true;
$config['password_min_length'] = 10;
