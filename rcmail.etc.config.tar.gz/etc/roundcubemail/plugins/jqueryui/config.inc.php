<?php

// if you want to load localization strings for specific sub-libraries of jquery-ui, configure them here 
$config['jquery_ui_i18n'] = ['datepicker'];

// map Roundcube skins with jquery-ui themes here
$config['jquery_ui_skin_map'] = [
  'larry' => 'larry',
  'default' => 'elastic',
];
