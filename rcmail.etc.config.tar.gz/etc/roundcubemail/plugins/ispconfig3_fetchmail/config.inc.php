<?php
$config['fetchmail_limit'] = 3;